import datetime

datetime_object = datetime.datetime.now()
print(datetime_object)
print(have a good day)
