/* 
    Random number between 1 to 100
*/
    var x = Math.floor((Math.random() * 100) + 1);
    console.log(x);
